var config = {
    map: {
        '*': {
            'Magento_Checkout/template/authentication.html':
                'Diglin_Username/template/authentication.html'
            //'Magento_Checkout/form/element/email':
            //    'Diglin_Username/form/element/email',
            //'Magento_Checkout/form/element/email.html':
            //    'Diglin_Username/form/element/email.html'
        }
    }
};