<?php
/**
 * Created by Skynix Team.
 * 
 * Skynix Paypal Duplicated Orders
 */
 
 \Magento\Framework\Component\ComponentRegistrar::register(
     \Magento\Framework\Component\ComponentRegistrar::MODULE,
     'Skynix_PaypalDuplicatedOrders',
     __DIR__
 );
