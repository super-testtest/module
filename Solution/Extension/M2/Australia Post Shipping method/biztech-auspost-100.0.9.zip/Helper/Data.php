<?php

namespace Biztech\Auspost\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Module\ModuleListInterface;
use Magento\Config\Model\ResourceModel\Config;
use Magento\Framework\App\Config\ReinitableConfigInterface;
use Magento\Store\Model\Website;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;

class Data extends AbstractHelper
{

    const XML_PATH_ENABLED = 'carriers/auspost/active';
    const XML_API_KEY = 'carriers/auspost/auspost_api_key';
    const XML_PATH_INSTALLED = 'auspost/activation/installed';
    const XML_PATH_DATA = 'auspost/activation/data';
    const XML_PATH_WEBSITES = 'auspost/activation/websites';
    const XML_PATH_EN = 'auspost/activation/en';
    const XML_PATH_KEY = 'auspost/activation/key';

    protected $moduleList;
    protected $zend;
    protected $resourceConfig;
    protected $encryptor;
    protected $web;
    protected $objectManager;
    protected $coreConfig;
    protected $store;
    protected $curl;

    /**
     * Data constructor.
     *
     * @param Context                   $context
     * @param EncryptorInterface        $encryptor
     * @param LoggerInterface           $logger
     * @param ModuleListInterface       $moduleList
     * @param ScopeConfigInterface      $scopeConfig
     * @param StoreManagerInterface     $storeManager
     * @param Config                    $resourceConfig
     * @param ReinitableConfigInterface $coreConfig
     * @param Website                   $web
     * @param Curl                      $curl
     */
    public function __construct(
        Context $context, EncryptorInterface $encryptor, ModuleListInterface $moduleList, Config $resourceConfig, ReinitableConfigInterface $coreConfig, Website $web, Curl $curl, StoreManagerInterface $storeManager
    ) {
        $this->_logger = $context->getLogger();
        $this->_moduleList = $moduleList;
        $this->_storeManager = $storeManager;
        $this->scopeConfig = $context->getScopeConfig();
        $this->_resourceConfig = $resourceConfig;
        $this->_encryptor = $encryptor;
        $this->_web = $web;
        $this->_coreConfig = $coreConfig;
        $this->_curl = $curl;
        parent::__construct($context);
    }

    /**
     * @param  $query
     * @return string
     */
    public function buildHttpQuery($query)
    {
        $queryArray = [];
        foreach ($query as $key => $keyValue) {
            $queryArray[] = $key . '=' . urlencode($keyValue);
        }
        return implode('&', $queryArray);
    }

    /**
     * @param  $xmlString
     * @return array
     */
    public function parseXml($xmlString)
    {
        libxml_use_internal_errors(true);
        $xmlObject = simplexml_load_string($xmlString);
        $result = [];
        if (!empty($xmlObject)) {
            $this->convertXmlObjToArr($xmlObject, $result);
        }
        return $result;
    }

    /**
     * @param $obj
     * @param $arr
     */
    public function convertXmlObjToArr($obj, &$arr)
    {
        $children = $obj->children();
        $executed = false;
        foreach ($children as $elementName => $node) {
            if (is_array($arr) && array_key_exists($elementName, $arr)) {
                if (is_array($arr[$elementName]) && array_key_exists(0, $arr[$elementName])) {
                    $i = count($arr[$elementName]);
                    $this->convertXmlObjToArr($node, $arr[$elementName][$i]);
                } else {
                    $tmp = $arr[$elementName];
                    $arr[$elementName] = [];
                    $arr[$elementName][0] = $tmp;
                    $i = count($arr[$elementName]);
                    $this->convertXmlObjToArr($node, $arr[$elementName][$i]);
                }
            } else {
                $arr[$elementName] = [];
                $this->convertXmlObjToArr($node, $arr[$elementName]);
            }
            $executed = true;
        }
        if (!$executed && $children->getName() == "") {
            $arr = (String) $obj;
        }
        return;
    }

    /**
     * @param  $url
     * @param  array $headers
     * @param  bool  $auth
     * @return mixed
     */
    public function ausPostValidation($url)
    {
        $apiKey = $this->scopeConfig->getValue(self::XML_API_KEY, ScopeInterface::SCOPE_STORE);
        $cRequest = curl_init();
        curl_setopt($cRequest, CURLOPT_URL, $url);
        curl_setopt($cRequest, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt(
            $cRequest, CURLOPT_HTTPHEADER, [
            'Auth-Key: ' . $apiKey
            ]
        );
        curl_setopt($cRequest, CURLOPT_RETURNTRANSFER, 1);
        $contents = curl_exec($cRequest);
        curl_close($cRequest);
        return $contents;
    }

    /**
     * @return array
     */
    public function getAllStoreDomains()
    {
        $domains = [];
        foreach ($this->_storeManager->getWebsites() as $website) {
            $url = $website->getConfig('web/unsecure/base_url');
            if ($domain = trim(preg_replace('/^.*?\/\/(.*)?\//', '$1', $url))) {
                $domains[] = $domain;
            }
            $url = $website->getConfig('web/secure/base_url');
            if ($domain = trim(preg_replace('/^.*?\/\/(.*)?\//', '$1', $url))) {
                $domains[] = $domain;
            }
        }
        return array_unique($domains);
    }

    /**
     * @return mixed
     */
    public function getDataInfo()
    {
        $data = $this->scopeConfig->getValue(self::XML_PATH_DATA, ScopeInterface::SCOPE_STORE);
        return json_decode(base64_decode($this->_encryptor->decrypt($data)));
    }

    /**
     * @return array
     */
    public function getAllWebsites()
    {
        $value = $this->scopeConfig->getValue(self::XML_PATH_INSTALLED, ScopeInterface::SCOPE_STORE);
        if (!$value) {
            return [];
        }
        $data = $this->scopeConfig->getValue(self::XML_PATH_DATA, ScopeInterface::SCOPE_STORE);
        $web = $this->scopeConfig->getValue(self::XML_PATH_WEBSITES, ScopeInterface::SCOPE_STORE);
        $websitesArray = explode(',', str_replace($data, '', $this->_encryptor->decrypt($web)));
        $websites = array_diff($websitesArray, [""]);
        return $websites;
    }

    /**
     * @param  $url
     * @return mixed
     */
    public function getFormatUrl($url)
    {
        $input = trim($url, '/');
        if (!preg_match('#^http(s)?://#', $input)) {
            $input = 'http://' . $input;
        }
        $urlParts = parse_url($input);
        if (isset($urlParts['path'])) {
            $domain = preg_replace('/^www\./', '', $urlParts['host'] . $urlParts['path']);
        } else {
            $domain = preg_replace('/^www\./', '', $urlParts['host']);
        }
        return $domain;
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        $websiteId = $this->_storeManager->getStore()->getWebsite()->getId();
        $isEnabled = $this->scopeConfig->getValue(self::XML_PATH_ENABLED, ScopeInterface::SCOPE_STORE);
        if ($isEnabled) {
            if ($websiteId) {
                $websites = $this->getAllWebsites();
                $key = $this->scopeConfig->getValue(self::XML_PATH_KEY, ScopeInterface::SCOPE_STORE);
                if ($key == null || $key == '') {
                    return false;
                } else {
                    $enPath = $data = $this->scopeConfig->getValue(self::XML_PATH_EN, ScopeInterface::SCOPE_STORE);
                    if ($isEnabled && $enPath && in_array($websiteId, $websites)) {
                        return true;
                    } else {
                        return false;
                    }
                }
            } else {
                $enPath = $enPath = $data = $this->scopeConfig->getValue(self::XML_PATH_EN, ScopeInterface::SCOPE_STORE);
                if ($isEnabled && $enPath) {
                    return true;
                }
            }
        }
    }
    /**
     * @return boolean
     * 25-11-2019 | added by Jitendra - specific storeview activation checking
     */
    public function  enableSiteForStoreview()
    {
        $websites = $this->getAllWebsites();
        if(!empty($websites))
        {
            $currentWebsite = $this->_storeManager->getStore()->getWebsite()->getId();
            if(in_array($currentWebsite, $websites))
            {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

}
