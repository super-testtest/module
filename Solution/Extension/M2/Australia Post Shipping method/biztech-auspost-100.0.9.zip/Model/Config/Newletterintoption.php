<?php
namespace Biztech\Auspost\Model\Config;
use Magento\Framework\Option\ArrayInterface;
class Newletterintoption implements ArrayInterface
{

    /**
     * @return array
     */
    public function toOptionArray()
    {

        $options = [
            ['value' => '', 'label' => __('Please Select')],
            ['value' => 'INT_LETTER_COR_OWN_PACKAGING ', 'label' => __('Courier')],
            ['value' => 'INT_LETTER_EXP_OWN_PACKAGING', 'label' => __('Express')],
            ['value' => 'INT_LETTER_REG_SMALL_ENVELOPE', 'label' => __('Registered Post DL')],
            ['value' => 'INT_LETTER_REG_LARGE_ENVELOPE', 'label' => __('Registered Post B4')],
            ['value' => 'INT_LETTER_AIR_OWN_PACKAGING_LIGHT', 'label' => __('Economy Air')],
        ];
        return $options;
    }

}
