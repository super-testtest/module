<?php

namespace Biztech\Auspost\Model\Config;

use Magento\Framework\Option\ArrayInterface;
class Letterdomesticoption implements ArrayInterface
{

    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            ['value' => '', 'label' => __('Please Select')],
            ['value' => 'AUS_LETTER_REGULAR_SMALL', 'label' => __('Regular Letter Small')],
            ['value' => 'AUS_LETTER_REGULAR_MEDIUM', 'label' => __('Regular Letter Medium')],
            ['value' => 'AUS_LETTER_REGULAR_LARGE', 'label' => __('Regular Letter Large')],
            ['value' => 'AUS_LETTER_EXPRESS_SMALL', 'label' => __('Express Post Small Envelope')],
            ['value' => 'AUS_LETTER_EXPRESS_MEDIUM', 'label' => __('Express Post Medium Envelope')],
            ['value' => 'AUS_LETTER_EXPRESS_LARGE', 'label' => __('Express Post Large Envelope')],
            ['value' => 'AUS_LETTER_REGULAR_LARGE_125', 'label' => __('Large Letter')],
            ['value' => 'AUS_LETTER_PRIORITY_LARGE_125', 'label' => __('Large Priority Letter')],
            ['value' => 'AUS_LETTER_PRIORITY_SMALL', 'label' => __('Small Priority Letter')],
        ];
        return $options;
    }

}
