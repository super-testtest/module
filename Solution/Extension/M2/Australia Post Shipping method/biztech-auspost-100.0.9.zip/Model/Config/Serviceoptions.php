<?php
namespace Biztech\Auspost\Model\Config;
use Magento\Framework\Option\ArrayInterface;
class Serviceoptions implements ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {

        $options = [
            ['value' => '', 'label' => __('Please Select')],
            ['value' => 'AUS_PARCEL_REGULAR', 'label' => __('Standard')],
            ['value' => 'AUS_PARCEL_EXPRESS', 'label' => __('Express')],
            ['value' => 'AUS_PARCEL_COURIER', 'label' => __('Courier')],
        ];
        return $options;
    }

}
