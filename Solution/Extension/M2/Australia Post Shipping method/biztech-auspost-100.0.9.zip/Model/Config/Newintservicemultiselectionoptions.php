<?php

namespace Biztech\Auspost\Model\Config;
use Magento\Framework\Option\ArrayInterface;
class NewintServiceMultiSelectionOptions implements ArrayInterface
{

    /**
     * @return array
     */
    public function toOptionArray()
    {

        $options = [
            ['value' => '', 'label' => __('Please Select')],
            ['value' => 'INT_PARCEL_COR_OWN_PACKAGING', 'label' => __('Courier')],
            ['value' => 'INT_PARCEL_EXP_OWN_PACKAGING', 'label' => __('Express')],
            ['value' => 'INT_PARCEL_STD_OWN_PACKAGING', 'label' => __('Standard')],
            ['value' => 'INT_PARCEL_AIR_OWN_PACKAGING', 'label' => __('Economy Air')],
            ['value' => 'INT_PARCEL_SEA_OWN_PACKAGING', 'label' => __('Economy Sea')]
        ];
        return $options;
    }

}
