<?php

namespace Biztech\Auspost\Model;

use  Biztech\Auspost\Helper\Data;
use  Magento\Framework\App\Config\MutableScopeConfigInterface;

class Observer
{

    /**
     * @var \Biztech\Auspost\Helper\Data $helper
     */
    protected $helper;

    /**
     * @var \Magento\Framework\App\Config\MutableScopeConfigInterface
     */
    protected $mutableConfig;

    /**
     * @param \Biztech\Auspost\Helper\Data                              $helper
     * @param \Magento\Framework\App\Config\MutableScopeConfigInterface $mutableConfig
     */
    public function __construct(
        Data $helper,
        MutableScopeConfigInterface $mutableConfig
    ) {
        $this->helper = $helper;
        $this->mutableConfig = $mutableConfig;
    }

}
