<?php

namespace Biztech\Auspost\Model\Entity\Attribute\Source;

use  Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

class Packagetype extends AbstractSource
{

    /**
     * @return array
     */
    public function getAllOptions()
    {

        $type = [0 => "Parcel", 1 => "Letter"];
        foreach ($type as $key => $type) {
            $allTypes[] = ['label' => $type, 'value' => $key];
        }
        return $allTypes;
    }

}
