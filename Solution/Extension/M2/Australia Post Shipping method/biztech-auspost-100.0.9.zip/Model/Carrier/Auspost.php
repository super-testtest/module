<?php

namespace Biztech\Auspost\Model\Carrier;

use Biztech\Auspost\Helper\Data;
use Biztech\Auspost\Logger\Logger;
use Biztech\Auspost\Model\Carrier\Pack;
use Magento\Backend\Model\Session\Quote;
use Magento\Checkout\Model\Cart;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\ObjectManagerInterface;
use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory;
use Magento\Quote\Model\Quote\Address\RateResult\MethodFactory;
use Magento\Shipping\Model\Carrier\AbstractCarrier;
use Magento\Shipping\Model\Carrier\CarrierInterface;
use Magento\Shipping\Model\Rate\ResultFactory;
use Zend\Json\Json;

class Auspost extends AbstractCarrier implements CarrierInterface
{

    private $_apiHttps = 'https://digitalapi.auspost.com.au/postage';
    protected $_code = 'auspost';
    protected $numBoxes = 1;
    protected $_itemPackage = 0;
    protected $_rateResultFactory;
    protected $_rateMethodFactory;
    protected $_helperData;
    protected $_cart;
    protected $_checkoutsession;
    protected $_objectManager;
    protected $_rateErrorFactory;
    protected $_zend;
    protected $_adminCheckoutSession;
    protected $_pack;
    protected $_objHelperWeight;

    const HANDLING_TYPE_PERCENT = 'P';
    const HANDLING_TYPE_FIXED = 'F';
    const HANDLING_ACTION_PERPACKAGE = 'P';
    const HANDLING_ACTION_PERORDER = 'O';

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        ErrorFactory $rateErrorFactory,
        \Psr\Log\LoggerInterface $logger,
        ResultFactory $rateResultFactory,
        MethodFactory $rateMethodFactory,
        ObjectManagerInterface $objectmanager,
        Data $helperdata,
        Cart $cart,
        Session $checkoutsession,
        Json $zend,
        Quote $adminCheckoutSession,
        Pack $pack,
        \Magento\Directory\Helper\Data $objHelperWeight,
        array $data = []
    ) {
        $this->_rateResultFactory = $rateResultFactory;
        $this->_rateMethodFactory = $rateMethodFactory;
        $this->_helperData = $helperdata;
        $this->_objectManager = $objectmanager;
        $this->_cart = $cart;
        $this->_pack = $pack;
        $this->_checkoutsession = $checkoutsession;
        $this->_zend = $zend;
        $this->_adminCheckoutSession = $adminCheckoutSession;
        $this->_objHelperWeight = $objHelperWeight;
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }

    public function collectRates(RateRequest $request)
    {
        if ((!$this->_scopeConfig->getValue('carriers/auspost/active', \Magento\Store\Model\ScopeInterface::SCOPE_STORE)) || (!in_array($request->getStoreId(), $this->_helperData->getAllWebsites()))) {
            return false;
        }
        $result = $this->_rateResultFactory->create();
        if(!$this->_helperData->enableSiteForStoreview()) {
            return false;
        }
        if (!$this->_helperData->isEnabled()) {
            if (!$this->getConfigData('active')) {
                return false;
            }
        }

        /* Check if weight excceds */
        $weightFlag = false;
        $maxAllowedWeight = 0;
        $totalWeight = 0;

        $attr = $this->_objectManager->get('Magento\Catalog\Model\Product')->getResource()->getAttribute('auspost_package_type');
        $weight = 0;
        $packageType = "";
        $boxes = array();

        $length = 0;
        $width = 0;
        $height = 0;

        $lengthAttr = $this->getConfigData('length_attribute');
        $widthAttr = $this->getConfigData('width_attribute');
        $heightAttr = $this->getConfigData('height_attribute');

        $defaultWeightUnit = $this->_objHelperWeight->getWeightUnit();

        if ($request->getAllItems()) {
            foreach ($request->getAllItems() as $item) {
                /* Do not allow configurable product to as the dimensions can be differ for its simple products */
                if ($item->getHasChildren() && $item->getProduct()->getTypeId() == "configurable") {
                    continue;
                }

                if ($item->getProduct()->getTypeId() == "bundle" && $item->isShipSeparately()) {
                    continue;
                }

                /* Do not allow simple products of bundle product */
                if ($item->getParentItem()) {
                    if ($item->getParentItem()->getProduct()->getTypeId() == "bundle" && !$item->isShipSeparately()) {
                        continue;
                    }
                }

                if ($item->getHasChildren() && $item->isShipSeparately()) {
                    $productItemObj = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($item->getProductId());
                    if ($attr->usesSource()) {
                        $packageTypeArr[] = $attr->getSource()->getOptionText($productItemObj->getData('auspost_package_type')) ? $attr->getSource()->getOptionText($productItemObj->getData('auspost_package_type')) : 'Parcel';
                    }

                    foreach ($item->getChildren() as $child) {
                        if ($child->getFreeShipping() && !$child->getProduct()->isVirtual()) {
                            $productId = $child->getProductId();
                            $productObj = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($productId);
                            $itemQty = $item->getParentItem() ? $item->getParentItem()->getQty() : $item->getQty();

                            for ($i = 1; $i <= $itemQty; $i++) {
                                $boxes[$item->getId() . "-" . $productId] = [
                                    'length' => $productObj->getData($lengthAttr) ? $productObj->getData($lengthAttr) : $this->getConfigData('length_value'),
                                    'width' => $productObj->getData($widthAttr) ? $productObj->getData($widthAttr) : $this->getConfigData('width_value'),
                                    'height' => $productObj->getData($heightAttr) ? $productObj->getData($heightAttr) : $this->getConfigData('height_value'),
                                ];
                                $totalWeight += $item->getWeight();
                            }
                        }
                    }
                } else {
                    $productId = $item->getProductId();
                    $productObj = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($productId);
                    if ($attr->usesSource()) {
                        $packageTypeArr[] = $attr->getSource()->getOptionText($productObj->getData('auspost_package_type')) ? $attr->getSource()->getOptionText($productObj->getData('auspost_package_type')) : 'Parcel';
                    }
                    $itemQty = $item->getParentItem() ? $item->getParentItem()->getQty() : $item->getQty();
                    if ($item->getParentItem() && $item->getParentItem()->getProduct()->getTypeId() == "bundle") {
                        $totalWeight += $itemQty * ($item->getWeight());
                    } else {
                        $totalWeight += $itemQty * ($item->getParentItem() ? $item->getParentItem()->getWeight() : $item->getWeight());
                    }

                    $prdLength = $productObj->getData($lengthAttr);
                    $prdWidth = $productObj->getData($widthAttr);
                    $prdHeight = $productObj->getData($heightAttr);
                    if ($this->getConfigData('auspost_allow_default')) {
                        $prdLength = $productObj->getData($lengthAttr) ? $productObj->getData($lengthAttr) : $this->getConfigData('length_value');
                        $prdWidth = $productObj->getData($widthAttr) ? $productObj->getData($widthAttr) : $this->getConfigData('width_value');
                        $prdHeight = $productObj->getData($heightAttr) ? $productObj->getData($heightAttr) : $this->getConfigData('height_value');
                    }

                    for ($i = 1; $i <= $itemQty; $i++) {
                        $boxes[$item->getId()] = [
                            'length' => $prdLength,
                            'width' => $prdWidth,
                            'height' => $prdHeight,
                        ];
                        $boxesArray[] = [
                            'length' => $prdLength,
                            'width' => $prdWidth,
                            'height' => $prdHeight,
                        ];
                    }
                }
            }
            $totalQuantity = $this->_cart->getQuote()->getItemsQty();
            if ($totalQuantity == 1) {
                $length = $prdLength = $productObj->getData($lengthAttr) ? $productObj->getData($lengthAttr) : $this->getConfigData('length_value');
                $width = $prdWidth = $productObj->getData($widthAttr) ? $productObj->getData($widthAttr) : $this->getConfigData('width_value');
                $height = $prdHeight = $productObj->getData($heightAttr) ? $productObj->getData($heightAttr) : $this->getConfigData('height_value');
            } else {
                $lp = $this->_pack;
                $lp->pack($boxesArray);
                $cSize = $lp->getContainerDimensions();

                $length = $cSize['length'];
                $width = $cSize['width'];
                $height = $cSize['height'];
            }

            //convert weight from lbs to kg if default weight is set to lbs
            if ($defaultWeightUnit == "lbs") {
                $totalWeight = $totalWeight * 0.45359237;
            }

            if ($this->getConfigData('weight_unit') == "gm") {
                $totalWeight = $totalWeight / 1000;
            }
        }

        $totalWeight = number_format($totalWeight, 2, '.', '');

        if ($totalWeight == 0) {
            $error = $this->_rateErrorFactory->create();
            $error->setCarrier($this->_code);
            $error->setCarrierTitle($this->getConfigData('shippingmethodconfiguration/title'));
            $error->setErrorMessage($this->getConfigData('specificerrmsg'));
            $result->append($error);
            return $result;
        }

        $packageTypeArr = array_unique($packageTypeArr);
        if (count($packageTypeArr) > 1) {
            $packageType = 'Parcel';
        } else {
            $packageType = $packageTypeArr[0];
        }

        if ($packageType != 'Letter') {
            /* Get max allowed weight for the parcel service */
            $maxParcelWeightAllowed = 0;
            if ($request['dest_country_id'] == 'AU') {
                $allowedParcelWeights = $this->apiRequest('parcel/domestic/weight');
                $maxParcelWeightAllowed = intval($allowedParcelWeights['weight'][count($allowedParcelWeights['weight']) - 1]['value']);
            } else {
                $allowedParcelWeights = $this->apiRequest('parcel/international/weight');
                $maxParcelWeightAllowed = intval($allowedParcelWeights['weight'][count($allowedParcelWeights['weight']) - 1]['value']);
            }

            $maxAllowedWeight = $maxParcelWeightAllowed;
            if ($totalWeight > $maxParcelWeightAllowed) {
                $weightFlag = true;
            }
        } else {
            /* Get max allowed weight for the letter service */
            $maxLetterWeightAllowed = 0;
            if ($request['dest_country_id'] == 'AU') {
                $allowedLetterWeights = $this->apiRequest('letter/domestic/weight');
                $maxLetterWeightAllowed = intval($allowedLetterWeights['weight'][count($allowedLetterWeights['weight']) - 1]['value']);
            } else {
                $allowedLetterWeights = $this->apiRequest('letter/international/weight');
                $maxLetterWeightAllowed = intval($allowedLetterWeights['weight'][count($allowedLetterWeights['weight']) - 1]['value']);
            }

            $maxAllowedWeight = $maxLetterWeightAllowed;
            if ($totalWeight > $maxLetterWeightAllowed) {
                $weightFlag = true;
            }
        }

        /* Ship sapratly if weight limit excceds */
        if ($weightFlag) {
            if ($this->getConfigData('auspost_package_item')) {
                $serviceChargeArr = "";
                foreach ($request->getAllItems() as $item) {
                    if ($item->getQty() == 1 && $item->getRowWeight() > $maxAllowedWeight) {
                        $this->_logger->info('No service is available');
                        $error = $this->_rateErrorFactory->create();
                        $error->setCarrier($this->_code);
                        $error->setCarrierTitle($this->getConfigData('title'));
                        $error->setErrorMessage($this->getConfigData('specificerrmsg'));
                        $result->append($error);
                        return $result;
                    } else {
                        $itemBoxes = "";
                        if ($item->getHasChildren()) {
                            // Do not allow configurable product to as the dimensions can be differ for its simple products
                            if ($item->getProduct()->getTypeId() == "configurable") {
                                continue;
                            }
                            //Do not allow bundle product if its child's allow to ship seprately
                            if ($item->getProduct()->getTypeId() == "bundle" && $item->isShipSeparately()) {
                                continue;
                            }
                        }
                        /* Do not allow simple products of bundle product */
                        if ($item->getParentItem()) {
                            if ($item->getParentItem()->getProduct()->getTypeId() == "bundle" && !$item->getParentItem()->isShipSeparately()) {
                                continue;
                            }
                        }

                        $itemQty = $itemQty = $item->getParentItem() ? $item->getParentItem()->getQty() : $item->getQty();
                        $rowWeight = $itemQty * ($item->getParentItem() ? $item->getParentItem()->getWeight() : $item->getWeight());
                        if ($itemQty > 1 && $rowWeight < $maxAllowedWeight) {
                            $itemQty = $item->getParentItem() ? $item->getParentItem()->getQty() : $item->getQty();
                            for ($j = 0; $j < $itemQty; $j++) {
                                $itemBoxes[] = $boxes[$item->getId()];
                            }
                            $weight = $itemQty * ($item->getParentItem() ? $item->getParentItem()->getWeight() : $item->getWeight());
                            $this->_itemPackage = $this->_itemPackage + 1;
                        } else {
                            $itemBoxes[] = $boxes[$item->getId()];
                            $itemQty = $itemQty = $item->getParentItem() ? $item->getParentItem()->getQty() : $item->getQty();
                            $midWeight = $itemQty * ($item->getParentItem() ? $item->getParentItem()->getWeight() : $item->getWeight());
                            $weight = $midWeight / $itemQty;
                            $this->_itemPackage = $this->_itemPackage + $itemQty;
                        }

                        $packageDimension = $this->_pack;
                        $packageDimension->pack($itemBoxes);
                        $itemSize = $packageDimension->getContainerDimensions();

                        $length = $itemSize['length'];
                        $width = $itemSize['width'];
                        $height = $itemSize['height'];

                        //convert weight from lbs to kg if default weight is set to lbs
                        if ($defaultWeightUnit == "lbs") {
                            $weight = $weight * 0.45359237;
                        }

                        if ($this->getConfigData('weight_unit') == "gm") {
                            $weight = $weight / 1000;
                        }

                        $weight = number_format($weight, 2, '.', '');

                        if ($request['dest_country_id'] == 'AU') {
                            if ($packageType != 'Letter') {
                                $resorce = 'parcel/domestic/service';
                                $params = [
                                    'from_postcode' => $this->getConfigData('auspost_from_shipping_postcode'),
                                    'to_postcode' => $request['dest_postcode'],
                                    'length' => $length,
                                    'width' => $width,
                                    'height' => $height,
                                    'weight' => $weight,
                                ];

                                $enableServices = explode(',', $this->getConfigData('auspost_enable_services'));
                            } else {
                                $resorce = 'letter/domestic/service';
                                $params = [
                                    'length' => $length * 10,
                                    'width' => $width * 10,
                                    'thickness' => $height * 10,
                                    'weight' => $weight * 1000,
                                ];
                                $enableServices = explode(',', $this->getConfigData('auspost_enable_services_letter'));
                            }
                            $_servicesArr = $this->apiRequest($resorce, $params);
                        } else {
                            if ($packageType != 'Letter') {
                                $resorce = 'parcel/international/service';
                                $enableServices = explode(',', $this->getConfigData('auspost_enable_int_services'));
                                $_servicesArr = $this->apiRequest(
                                    $resorce,
                                    [
                                        'country_code' => $request['dest_country_id'],
                                        'weight' => $weight,
                                    ]
                                );
                            } else {
                                $resorce = 'letter/international/service';
                                $enableServices = explode(',', $this->getConfigData('auspost_enable_int_services_letter'));
                                $_servicesArr = $this->apiRequest(
                                    $resorce,
                                    [
                                        'country_code' => $request['dest_country_id'],
                                        'weight' => $weight * 1000,
                                    ]
                                );
                            }
                        }

                        /* Redefine service array to calculate Postage */
                        $_services = $this->getServiceArray($request, $_servicesArr);
                        $checkService = array(); /* Checking on Service if already exist for separate shipping */

                        if (!count($_services)) {
                            if (isset($_servicesArr['errorMessage'])) {
                                $this->_logger->info($_servicesArr['errorMessage']);
                            }
                            $error = $this->_rateErrorFactory->create();
                            $error->setCarrier($this->_code);
                            $error->setCarrierTitle($this->getConfigData('title'));
                            $error->setErrorMessage($this->getConfigData('specificerrmsg'));
                            $result->append($error);
                            return $result;
                        }

                        $extraCover = '';

                        foreach ($_services as $_value) {

                            if ((strpos($_value['code'], 'AUS_LETTER_REGULAR_SMALL') !== false && in_array('AUS_LETTER_REGULAR_SMALL', $enableServices)) || (strpos($_value['code'], 'AUS_LETTER_REGULAR_MEDIUM') !== false && in_array('AUS_LETTER_REGULAR_MEDIUM', $enableServices)) || (strpos($_value['code'], 'AUS_LETTER_REGULAR_LARGE') !== false && in_array('AUS_LETTER_REGULAR_LARGE', $enableServices))) { } else {
                                if (!in_array($_value['code'], $enableServices)) {
                                    continue;
                                }
                            }

                            if (!empty($_value['options'])) {
                                foreach ($_value['options'] as $_val) {
                                    //check is the admin
                                    $appState = $this->_objectManager->get('\Magento\Framework\App\State');
                                    $areaCode = $appState->getAreaCode();
                                    if ($appState->getAreaCode() == \Magento\Backend\App\Area\FrontNameResolver::AREA_CODE) {
                                        $totals = $this->_adminCheckoutSession->getQuote();
                                        $subtotal = $totals->getSubtotal();
                                    } else {
                                        $totals = $this->_checkoutsession->getQuote()->getTotals();
                                        $subtotal = $totals["subtotal"]->getValue();
                                    }
                                    if (isset($_val['max_extra_cover'])) {
                                        if ($subtotal > $_val['max_extra_cover']) {
                                            $extraCover = $_val['max_extra_cover'];
                                        } else {
                                            $extraCover = round($subtotal);
                                        }
                                    }

                                    if ($extraCover == 0) {
                                        $extraCover = '';
                                    }
                                    if ($request['dest_country_id'] == 'AU') {
                                        if ($packageType != 'Letter') {
                                            $params = [
                                                'from_postcode' => $this->getConfigData('auspost_from_shipping_postcode'),
                                                'to_postcode' => $request['dest_postcode'],
                                                'length' => $length,
                                                'width' => $width,
                                                'height' => $height,
                                                'weight' => $weight,
                                                'service_code' => $_value['code'],
                                                'option_code' => $_val['code'],
                                            ];

                                            if ($this->getConfigData('auspost_add_extra_cover_price') && isset($_val['max_extra_cover'])) {
                                                $params['suboption_code'] = 'AUS_SERVICE_OPTION_EXTRA_COVER';
                                                $params['extra_cover'] = $extraCover;
                                            }
                                            $res = $this->apiRequest('parcel/domestic/calculate', $params);
                                        } else {
                                            $params = [
                                                'weight' => $weight * 1000,
                                                'service_code' => $_value['code'],
                                                'option_code' => $_val['code'],
                                            ];

                                            if ($this->getConfigData('auspost_add_extra_cover_price') && isset($_val['max_extra_cover'])) {
                                                $params['suboption_code'] = 'AUS_SERVICE_OPTION_EXTRA_COVER';
                                                $params['extra_cover'] = $extraCover;
                                                $params['suboption_name'] = $_val['suboption_name'];
                                            }

                                            $res = $this->apiRequest('letter/domestic/calculate', $params);
                                        }
                                    } else {
                                        if ($_val['code'] != 'INT_EXTRA_COVER') {
                                            if ($packageType != 'Letter') {
                                                $params = [
                                                    'country_code' => $request['dest_country_id'],
                                                    'weight' => $weight,
                                                    'service_code' => $_value['code'],
                                                    'option_code' => $_val['code'],
                                                ];
                                            } else {
                                                $params = [
                                                    'country_code' => $request['dest_country_id'],
                                                    'weight' => $weight * 1000,
                                                    'service_code' => $_value['code'],
                                                    'option_code' => $_val['code'],
                                                ];
                                            }
                                        } else {
                                            if ($packageType != 'Letter') {
                                                $params = [
                                                    'country_code' => $request['dest_country_id'],
                                                    'weight' => $weight,
                                                    'service_code' => $_value['code'],
                                                    'option_code' => $_val['code'],
                                                    'extra_cover' => $extraCover,
                                                ];
                                            } else {
                                                $params = [
                                                    'country_code' => $request['dest_country_id'],
                                                    'weight' => $weight * 1000,
                                                    'service_code' => $_value['code'],
                                                    'option_code' => $_val['code'],
                                                    'extra_cover' => $extraCover,
                                                ];
                                            }
                                        }
                                        if ($packageType != 'Letter') {
                                            $res = $this->apiRequest('parcel/international/calculate', $params);
                                        } else {
                                            $res = $this->apiRequest('letter/international/calculate', $params);
                                        }
                                    }

                                    //IF Qty > 1 can be sent as single package or multiple package
                                    $currentItemQty = $item->getParentItem() ? $item->getParentItem()->getQty() : $item->getQty();
                                    $current_row_weight = $item->getParentItem() ? $item->getParentItem()->getRowWeight() : $item->getRowWeight();

                                    if (isset($res['total_cost'])) {

                                        if ($currentItemQty > 1 && $current_row_weight < $maxAllowedWeight) {
                                            $shippingPrice = $res['total_cost'];
                                        } else {
                                            $shippingPrice = $currentItemQty * $res['total_cost'];
                                        }

                                        if (is_array($serviceChargeArr) && in_array($checkService, $serviceChargeArr)) {
                                            $current_charge = $serviceChargeArr[$_value['code'] . '_' . $_val['code']]['charge'];
                                            $serviceChargeArr[$_value['code'] . '_' . $_val['code']]['charge'] = $current_charge + $shippingPrice;
                                        } else {
                                            if (isset($_val['suboption_name'])) {
                                                $serviceChargeArr[$_value['code'] . '_' . $_val['code'] . '_' . $_val['suboption_code']]['method_title'] = $_value['name'] . ' - ' . $_val['name'] . ' - ' . $_val['suboption_name'];
                                                $serviceChargeArr[$_value['code'] . '_' . $_val['code'] . '_' . $_val['suboption_code']]['charge'] = $currentItemQty * $shippingPrice;
                                                $checkService[$_value['code'] . '_' . $_val['code'] . '_' . $_val['suboption_code']] = $_value['code'] . '_' . $_val['code'] . '_' . $_val['suboption_code'];
                                            } else {
                                                if ($_val['name']) {
                                                    $serviceChargeArr[$_value['code'] . '_' . $_val['code']]['method_title'] = $_value['name'] . ' - ' . $_val['name'];
                                                    $checkService[$_value['code'] . '_' . $_val['code']] = $_value['code'] . '_' . $_val['code'];
                                                } else {
                                                    $serviceChargeArr[$_value['code'] . '_' . $_val['code']]['method_title'] = $_value['name'];
                                                    $checkService[$_value['code'] . '_' . $_val['code']] = $_value['code'] . '_' . $_val['code'];
                                                }
                                                $serviceChargeArr[$_value['code'] . '_' . $_val['code']]['charge'] = $currentItemQty * $shippingPrice;
                                            }
                                        }
                                    }
                                }
                            } else {
                                //check is the admin
                                $appState = $this->_objectManager->get('\Magento\Framework\App\State');
                                $areaCode = $appState->getAreaCode();
                                if ($appState->getAreaCode() == \Magento\Backend\App\Area\FrontNameResolver::AREA_CODE) {
                                    $totals = $this->_adminCheckoutSession->getQuote();
                                    $subtotal = $totals->getSubtotal();
                                } else {
                                    $totals = $this->_checkoutsession->getQuote()->getTotals();
                                    $subtotal = $totals["subtotal"]->getValue();
                                }
                                if ($subtotal > $_value['max_extra_cover']) {
                                    $extraCover = $_value['max_extra_cover'];
                                } else {
                                    $extraCover = round($subtotal);
                                }
                                if ($extraCover == 0) {
                                    $extraCover = '';
                                }

                                if ($request['dest_country_id'] == 'AU') {
                                    if ($packageType != 'Letter') {
                                        $params = [
                                            'from_postcode' => $this->getConfigData('auspost_from_shipping_postcode'),
                                            'to_postcode' => $request['dest_postcode'],
                                            'length' => $length,
                                            'width' => $width,
                                            'height' => $height,
                                            'weight' => $weight,
                                            'service_code' => $_value['code'],
                                            'option_code' => $_val['code'],
                                        ];

                                        if ($this->getConfigData('auspost_add_extra_cover_price') && isset($_val['max_extra_cover'])) {
                                            $params['suboption_code'] = 'AUS_SERVICE_OPTION_EXTRA_COVER';
                                            $params['extra_cover'] = $extraCover;
                                        }
                                        $res = $this->apiRequest('parcel/domestic/calculate', $params);
                                    } else {
                                        $params = [
                                            'weight' => $weight * 1000,
                                            'service_code' => $_value['code'],
                                            'option_code' => $_val['code'],
                                        ];

                                        if ($this->getConfigData('auspost_add_extra_cover_price') && isset($_val['max_extra_cover'])) {
                                            $params['suboption_code'] = 'AUS_SERVICE_OPTION_EXTRA_COVER';
                                            $params['extra_cover'] = $extraCover;
                                            $params['suboption_name'] = $_val['suboption_name'];
                                        }

                                        $res = $this->apiRequest('letter/domestic/calculate', $params);
                                    }
                                } else {
                                    if ($_val['code'] != 'INT_EXTRA_COVER') {
                                        if ($packageType != 'Letter') {
                                            $params = [
                                                'country_code' => $request['dest_country_id'],
                                                'weight' => $weight,
                                                'service_code' => $_value['code'],
                                                'option_code' => $_val['code'],
                                            ];
                                        } else {
                                            $params = [
                                                'country_code' => $request['dest_country_id'],
                                                'weight' => $weight * 1000,
                                                'service_code' => $_value['code'],
                                                'option_code' => $_val['code'],
                                            ];
                                        }
                                    } else {
                                        if ($packageType != 'Letter') {
                                            $params = [
                                                'country_code' => $request['dest_country_id'],
                                                'weight' => $weight,
                                                'service_code' => $_value['code'],
                                                'option_code' => $_val['code'],
                                                'extra_cover' => $extraCover,
                                            ];
                                        } else {
                                            $params = [
                                                'country_code' => $request['dest_country_id'],
                                                'weight' => $weight * 1000,
                                                'service_code' => $_value['code'],
                                                'option_code' => $_val['code'],
                                                'extra_cover' => $extraCover,
                                            ];
                                        }
                                    }
                                    if ($packageType != 'Letter') {
                                        $res = $this->apiRequest('parcel/international/calculate', $params);
                                    } else {
                                        $res = $this->apiRequest('letter/international/calculate', $params);
                                    }
                                }
                                //IF Qty > 1 can be sent as single package or multiple package
                                $currentItemQty = $item->getParentItem() ? $item->getParentItem()->getQty() : $item->getQty();
                                $current_row_weight = $item->getParentItem() ? $item->getParentItem()->getRowWeight() : $item->getRowWeight();
                                $shippingPrice = $res['total_cost'];
                                if ($res['total_cost']) {
                                    if (is_array($serviceChargeArr) && array_key_exists($_value['code'], $serviceChargeArr)) {
                                        $current_charge = $serviceChargeArr[$_value['code']]['charge'];
                                        $serviceChargeArr[$_value['code']]['charge'] = $current_charge + $shippingPrice;
                                    } else {
                                        $serviceChargeArr[$_value['code']]['method_title'] = $_value['name'] . ' ';
                                        $serviceChargeArr[$_value['code']]['charge'] = $currentItemQty * $shippingPrice;
                                    }
                                } else {
                                    $error = $this->_rateErrorFactory->create();
                                    $error->setCarrier($this->_code);
                                    $error->setCarrierTitle($this->getConfigData('title'));
                                    $error->setErrorMessage($this->getConfigData('specificerrmsg'));
                                    $result->append($error);
                                    return $result;
                                }
                            }
                        }
                    }
                }

                if (count($serviceChargeArr)) {
                    foreach ($serviceChargeArr as $sevicecode => $servicedata) {
                        $fianlShippingPrice = $this->getFinalPriceWithHandlingFee($servicedata['charge']);
                        $method = $this->_rateMethodFactory->create();
                        $method->setCarrier($this->_code);
                        $method->setMethod($sevicecode);
                        $method->setCarrierTitle($this->getConfigData('title'));
                        $method->setMethodTitle($servicedata['method_title']);
                        $method->setPrice($fianlShippingPrice);
                        $method->setCost($fianlShippingPrice);
                        $result->append($method);
                    }
                } else {
                    $this->_logger->info('No service is available');
                    $error = $this->_rateErrorFactory->create();
                    $error->setCarrier($this->_code);
                    $error->setCarrierTitle($this->getConfigData('title'));
                    $error->setErrorMessage($this->getConfigData('specificerrmsg'));
                    $result->append($error);
                    return $result;
                }
            } else {
                $this->_logger->info('No service is available');
                $error = $this->_rateErrorFactory->create();
                $error->setCarrier($this->_code);
                $error->setCarrierTitle($this->getConfigData('title'));
                $error->setErrorMessage($this->getConfigData('specificerrmsg'));
                $result->append($error);
                return $result;
            }
        } else {
            /* Ship single packge */
            if ($request['dest_country_id'] == 'AU') {
                if ($packageType != 'Letter') {
                    $resorce = 'parcel/domestic/service';
                    $params = [
                        'from_postcode' => $this->getConfigData('auspost_from_shipping_postcode'),
                        'to_postcode' => $request['dest_postcode'],
                        'length' => $length,
                        'width' => $width,
                        'height' => $height,
                        'weight' => $totalWeight,
                    ];

                    $enableServices = explode(',', $this->getConfigData('auspost_enable_services'));
                } else {
                    $resorce = 'letter/domestic/service';
                    $params = [
                        'length' => $length * 10,
                        'width' => $width * 10,
                        'thickness' => $height * 10,
                        'weight' => $totalWeight * 1000,
                    ];
                    $enableServices = explode(',', $this->getConfigData('auspost_enable_services_letter'));
                }
                $_servicesArr = $this->apiRequest($resorce, $params);
            } else {
                if ($packageType != 'Letter') {
                    $resorce = 'parcel/international/service';
                    $enableServices = explode(',', $this->getConfigData('auspost_enable_int_services'));
                    $_servicesArr = $this->apiRequest(
                        $resorce,
                        [
                            'country_code' => $request['dest_country_id'],
                            'weight' => $totalWeight,
                        ]
                    );
                } else {
                    $resorce = 'letter/international/service';
                    $enableServices = explode(',', $this->getConfigData('auspost_enable_int_services_letter'));
                    $_servicesArr = $this->apiRequest(
                        $resorce,
                        [
                            'country_code' => $request['dest_country_id'],
                            'weight' => $totalWeight * 1000,
                        ]
                    );
                }
            }
            $_services = [];
            $_services = $this->getServiceArray($request, $_servicesArr);

            if (!count($_services)) {
                if (isset($_servicesArr['errorMessage'])) {
                    $this->_logger->info('No service is available');
                }
                $error = $this->_rateErrorFactory->create();
                $error->setCarrier($this->_code);
                $error->setCarrierTitle($this->getConfigData('title'));
                $error->setErrorMessage($this->getConfigData('specificerrmsg'));
                $result->append($error);
                return $result;
            }
            $extraCover = '';

            $continuedServices = 0;
            foreach ($_services as $_value) {

                if ((strpos($_value['code'], 'AUS_LETTER_REGULAR_SMALL') !== false && in_array('AUS_LETTER_REGULAR_SMALL', $enableServices)) || (strpos($_value['code'], 'AUS_LETTER_REGULAR_MEDIUM') !== false && in_array('AUS_LETTER_REGULAR_MEDIUM', $enableServices)) || (strpos($_value['code'], 'AUS_LETTER_REGULAR_LARGE') !== false && in_array('AUS_LETTER_REGULAR_LARGE', $enableServices))) { } else {
                    if (!in_array($_value['code'], $enableServices)) {
                        $continuedServices++;
                        continue;
                    }
                }

                if (!empty($_value['options'])) {
                    foreach ($_value['options'] as $_val) {
                        //check is the admin
                        $appState = $this->_objectManager->get('\Magento\Framework\App\State');
                        $areaCode = $appState->getAreaCode();
                        if ($appState->getAreaCode() == \Magento\Backend\App\Area\FrontNameResolver::AREA_CODE) {
                            $totals = $this->_adminCheckoutSession->getQuote();
                            $subtotal = $totals->getSubtotal();
                        } else {
                            $totals = $this->_checkoutsession->getQuote()->getTotals();
                            $subtotal = $totals["subtotal"]->getValue();
                        }
                        if (isset($_val['max_extra_cover'])) {
                            if ($subtotal > $_val['max_extra_cover']) {
                                $extraCover = $_val['max_extra_cover'];
                            } else {
                                $extraCover = round($subtotal);
                            }
                        }
                        if ($extraCover == 0) {
                            $extraCover = '';
                        }

                        if ($request['dest_country_id'] == 'AU') {
                            if ($packageType != 'Letter') {
                                $params = [
                                    'from_postcode' => $this->getConfigData('auspost_from_shipping_postcode'),
                                    'to_postcode' => $request['dest_postcode'],
                                    'length' => $length,
                                    'width' => $width,
                                    'height' => $height,
                                    'weight' => $totalWeight,
                                    'service_code' => $_value['code'],
                                    'option_code' => $_val['code'],
                                ];

                                if ($this->getConfigData('auspost_add_extra_cover_price') && isset($_val['max_extra_cover'])) {
                                    $params['suboption_code'] = isset($_val['suboption_code']) ? $_val['suboption_code'] : 'AUS_SERVICE_OPTION_EXTRA_COVER';
                                    $params['extra_cover'] = $extraCover;
                                }
                                $res = $this->apiRequest('parcel/domestic/calculate', $params);
                            } else {
                                if (isset($_val['suboption_code'])) {
                                    if ($_val['suboption_code'] != 'AUS_SERVICE_OPTION_EXTRA_COVER' || $extraCover == '') {
                                        $params = [
                                            'weight' => $totalWeight * 1000,
                                            'service_code' => $_value['code'],
                                            'option_code' => $_val['code'],
                                            'suboption_code' => $_val['suboption_code'],
                                            'suboption_name' => $_val['suboption_name'],
                                        ];
                                    } else {
                                        $params = [
                                            'weight' => $totalWeight * 1000,
                                            'service_code' => $_value['code'],
                                            'option_code' => $_val['code'],
                                            'suboption_code' => $_val['suboption_code'],
                                            'suboption_name' => $_val['suboption_name'],
                                            'extra_cover' => $extraCover,
                                        ];
                                    }
                                } else {
                                    $params = [
                                        'weight' => $totalWeight * 1000,
                                        'service_code' => $_value['code'],
                                        'option_code' => $_val['code'],
                                    ];
                                }
                                $res = $this->apiRequest('letter/domestic/calculate', $params);
                            }
                        } else {
                            if ($_val['code'] != 'INT_EXTRA_COVER') {
                                if ($packageType != 'Letter') {
                                    $params = [
                                        'country_code' => $request['dest_country_id'],
                                        'weight' => $totalWeight,
                                        'service_code' => $_value['code'],
                                        'option_code' => $_val['code'],
                                    ];
                                } else {
                                    $params = [
                                        'country_code' => $request['dest_country_id'],
                                        'weight' => $totalWeight * 1000,
                                        'service_code' => $_value['code'],
                                        'option_code' => $_val['code'],
                                    ];
                                }
                            } else {
                                if ($packageType != 'Letter') {
                                    $params = [
                                        'country_code' => $request['dest_country_id'],
                                        'weight' => $totalWeight,
                                        'service_code' => $_value['code'],
                                        'option_code' => $_val['code'],
                                        'extra_cover' => $extraCover,
                                    ];
                                } else {
                                    $params = [
                                        'country_code' => $request['dest_country_id'],
                                        'weight' => $totalWeight * 1000,
                                        'service_code' => $_value['code'],
                                        'option_code' => $_val['code'],
                                        'extra_cover' => $extraCover,
                                    ];
                                }
                            }
                            if ($packageType != 'Letter') {
                                $res = $this->apiRequest('parcel/international/calculate', $params);
                            } else {
                                $res = $this->apiRequest('letter/international/calculate', $params);
                            }
                        }

                        $this->_itemPackage = 1;

                        $shippingPrice = $this->getFinalPriceWithHandlingFee($res['total_cost']);

                        if ($res['total_cost']) {
                            $method = $this->_rateMethodFactory->create();
                            $method->setCarrier($this->_code);
                            $method->setMethod($_value['code'] . '_' . $_val['code']);
                            $method->setCarrierTitle($this->getConfigData('title'));
                            if ($_val['name']) {
                                $method->setMethodTitle($_value['name'] . ' - ' . $_val['name']);
                            } else {
                                $method->setMethodTitle($_value['name']);
                            }
                            if (isset($_val['suboption_name'])) {
                                $method->setMethod($_value['code'] . '_' . $_val['code'] . '_' . $_val['suboption_code']);
                                $method->setMethodTitle($_value['name'] . ' - ' . $_val['name'] . ' - ' . $_val['suboption_name']);
                            }
                            $method->setPrice($shippingPrice);
                            $method->setCost($shippingPrice);
                            $result->append($method);
                        } else {
                            $error = $this->_rateErrorFactory->create();
                            $error->setCarrier($this->_code);
                            $error->setCarrierTitle($this->getConfigData('title'));
                            $error->setErrorMessage($this->getConfigData('specificerrmsg'));
                            $result->append($error);
                            return $result;
                        }
                    }
                } else {
                    //check is the admin
                    $appState = $this->_objectManager->get('\Magento\Framework\App\State');
                    $areaCode = $appState->getAreaCode();
                    if ($appState->getAreaCode() == \Magento\Backend\App\Area\FrontNameResolver::AREA_CODE) {
                        $totals = $this->_adminCheckoutSession->getQuote();
                        $subtotal = $totals->getSubtotal();
                    } else {
                        $totals = $this->_checkoutsession->getQuote()->getTotals();
                        $subtotal = $totals["subtotal"]->getValue();
                    }

                    if ($subtotal > $_value['max_extra_cover']) {
                        $extraCover = $_value['max_extra_cover'];
                    } else {
                        $extraCover = round($subtotal);
                    }
                    if ($extraCover == 0) {
                        $extraCover = '';
                    }

                    if ($request['dest_country_id'] == 'AU') {
                        if ($packageType != 'Letter') {
                            $params = [
                                'from_postcode' => $this->getConfigData('auspost_from_shipping_postcode'),
                                'to_postcode' => $request['dest_postcode'],
                                'length' => $length,
                                'width' => $width,
                                'height' => $height,
                                'weight' => $weight,
                                'service_code' => $_value['code']
                            ];

                            if ($this->getConfigData('auspost_add_extra_cover_price') && isset($_val['max_extra_cover'])) {
                                $params['suboption_code'] = 'AUS_SERVICE_OPTION_EXTRA_COVER';
                                $params['extra_cover'] = $extraCover;
                            }
                            $res = $this->apiRequest('parcel/domestic/calculate', $params);
                        } else {
                            $params = [
                                'weight' => $weight * 1000,
                                'service_code' => $_value['code']
                            ];

                            if ($this->getConfigData('auspost_add_extra_cover_price') && isset($_val['max_extra_cover'])) {
                                $params['suboption_code'] = 'AUS_SERVICE_OPTION_EXTRA_COVER';
                                $params['extra_cover'] = $extraCover;
                                $params['suboption_name'] = $_val['suboption_name'];
                            }

                            $res = $this->apiRequest('letter/domestic/calculate', $params);
                        }
                    } else {
                        if ($packageType != 'Letter') {
                            $params = [
                                'country_code' => $request['dest_country_id'],
                                'weight' => $totalWeight,
                                'service_code' => $_value['code'],
                            ];
                        } else {
                            $params = [
                                'country_code' => $request['dest_country_id'],
                                'weight' => $totalWeight * 1000,
                                'service_code' => $_value['code'],
                            ];
                        }

                        if ($this->getConfigData('auspost_add_extra_cover_price_int_service') && isset($_val['max_extra_cover'])) {
                            $params['option_code'] = 'INT_EXTRA_COVER';
                            $params['extra_cover'] = $extraCover;
                        }

                        if ($packageType != 'Letter') {
                            $res = $this->apiRequest('parcel/international/calculate', $params);
                        } else {
                            $res = $this->apiRequest('letter/international/calculate', $params);
                        }
                    }

                    $this->_itemPackage = 1;

                    if (isset($res['total_cost'])) {
                        $shippingPrice = $this->getFinalPriceWithHandlingFee($res['total_cost']);
                        $method = $this->_rateMethodFactory->create();
                        $method->setCarrier($this->_code);
                        $method->setMethod($_value['code']);
                        $method->setCarrierTitle($this->getConfigData('title'));
                        $method->setMethodTitle($_value['name']);
                        $method->setPrice($shippingPrice);
                        $method->setCost($shippingPrice);
                        $result->append($method);
                    }
                }
            }
            if ($continuedServices == count($_services)) {
                $error = $this->_rateErrorFactory->create();
                $error->setCarrier($this->_code);
                $error->setCarrierTitle($this->getConfigData('title'));
                $error->setErrorMessage($this->getConfigData('specificerrmsg'));
                $result->append($error);
                return $result;
            }
        }
        return $result;
    }

    protected function getServiceArray($request, $_servicesArr)
    {
        $_services = [];
        if (isset($_servicesArr['service']['code'])) {
            $_services[] = [
                'code' => $_servicesArr['service']['code'],
                'name' => $_servicesArr['service']['name'],
            ];
        } else {
            if (isset($_servicesArr['service'])) {
                foreach ($_servicesArr['service'] as $_service) {

                    //Skip to define service if code was not available. 
                    if (!array_key_exists('code', $_service)) continue;

                    $options = [];
                    $_services[$_service['code']] = [
                        'code' => $_service['code'],
                        'name' => $_service['name'],
                        'max_extra_cover' => isset($_service['max_extra_cover']) ? $_service['max_extra_cover'] : null,
                    ];

                    if (isset($_service['options']['option'])) {
                        if ($request['dest_country_id'] == 'AU') {
                            if (isset($_service['options']['option']['code'])) {
                                $options[$_service['options']['option']['code']] = [
                                    'code' => $_service['options']['option']['code'],
                                    'name' => $_service['options']['option']['name'],
                                    'max_extra_cover' => $_service['options']['option']['suboptions']['option']['max_extra_cover'],
                                ];
                            } else {
                                foreach ($_service['options']['option'] as $_option) {
                                    if ($_option['code'] == 'AUS_SERVICE_OPTION_SIGNATURE_ON_DELIVERY') {
                                        if ($this->getConfigData('auspost_disable_signature_services')) {
                                            continue;
                                        }
                                    }

                                    if (isset($_option['suboptions'])) {
                                        if (isset($_option['suboptions']['option']['code'])) {
                                            if ($_option['suboptions']['option']['code'] == 'AUS_SERVICE_OPTION_EXTRA_COVER') {
                                                if (!$this->getConfigData('auspost_add_extra_cover_price')) {
                                                    $options[$_option['code']] = [
                                                        'code' => $_option['code'],
                                                        'name' => $_option['name'],
                                                    ];
                                                } else {
                                                    $options[$_option['code']] = [
                                                        'code' => $_option['code'],
                                                        'name' => $_option['name'],
                                                    ];

                                                    $options[$_option['code'] . '_' . $_option['suboptions']['option']['code']] = [
                                                        'code' => $_option['code'],
                                                        'name' => $_option['name'],
                                                        'max_extra_cover' => isset($_option['max_extra_cover']) ? $_option['max_extra_cover'] : $_service['max_extra_cover'],
                                                        'suboption_code' => $_option['suboptions']['option']['code'],
                                                        'suboption_name' => $_option['suboptions']['option']['name'],
                                                    ];
                                                }
                                            }
                                        } else {
                                            foreach ($_option['suboptions']['option'] as $subopt) {

                                                //Skip to define service if code was not available. 
                                                if (is_array($subopt)) {
                                                    if (!array_key_exists("code", $subopt)) {
                                                        continue;
                                                    }
                                                } else {
                                                    continue;
                                                }

                                                if ($subopt['code'] == 'AUS_SERVICE_OPTION_EXTRA_COVER') {
                                                    if (!$this->getConfigData('shippingservicesconfiguration/auspost_add_extra_cover_price')) {
                                                        continue;
                                                    }
                                                }

                                                if ($subopt['code'] == 'AUS_SERVICE_OPTION_EXTRA_COVER') {
                                                    if (!$this->getConfigData('auspost_add_extra_cover_price')) {
                                                        continue;
                                                    }
                                                }
                                                $options[$subopt['code']] = [
                                                    'code' => $_option['code'],
                                                    'name' => $_option['name'],
                                                ];
                                                $options[$_option['code'] . '_' . $subopt['code']] = [
                                                    'code' => $_option['code'],
                                                    'name' => $_option['name'],
                                                    'max_extra_cover' => isset($subopt['max_extra_cover']) ? $subopt['max_extra_cover'] : $_service['max_extra_cover'],
                                                    'suboption_code' => $subopt['code'],
                                                    'suboption_name' => $subopt['name'],
                                                ];
                                            }
                                        }
                                    } else {
                                        if (isset($_option['code'])) {
                                            if (isset($_option['suboptions']['option']['code']) == 'AUS_SERVICE_OPTION_EXTRA_COVER') {
                                                if (!$this->getConfigData('auspost_add_extra_cover_price')) {
                                                    $options[$_option['code']] = [
                                                        'code' => $_option['code'],
                                                        'name' => $_option['name'],
                                                    ];
                                                } else {
                                                    $options[$_option['code']] = [
                                                        'code' => $_option['code'],
                                                        'name' => $_option['name'],
                                                        'max_extra_cover' => isset($_option['max_extra_cover']) ? $_option['max_extra_cover'] : $_service['max_extra_cover'],
                                                    ];
                                                }
                                            } else {
                                                if (!$this->getConfigData('auspost_add_extra_cover_price')) {
                                                    $options[$_option['code']] = [
                                                        'code' => $_option['code'],
                                                        'name' => $_option['name'],
                                                    ];
                                                } else {
                                                    $options[$_option['code']] = [
                                                        'code' => $_option['code'],
                                                        'name' => $_option['name'],
                                                        'max_extra_cover' => isset($_option['max_extra_cover']) ? $_option['max_extra_cover'] : $_service['max_extra_cover'],
                                                    ];
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            $_services[$_service['code']]['options'] = $options;
                        } else {
                            if (isset($_service['options']['option']['code'])) {
                                if ($_service['options']['option']['code'] == 'INT_EXTRA_COVER') {
                                    if (!$this->getConfigData('auspost_add_extra_cover_price_int_service')) {
                                        continue;
                                    }
                                }

                                if ($_service['options']['option']['code'] == 'INT_SIGNATURE_ON_DELIVERY') {
                                    if ($this->getConfigData('auspost_disable_signature_services')) {
                                        continue;
                                    }
                                }

                                $options[$_service['options']['option']['code']] = [
                                    'code' => $_service['options']['option']['code'],
                                    'name' => $_service['options']['option']['name'],
                                    'max_extra_cover' => isset($_service['max_extra_cover']) ? $_service['max_extra_cover'] : null,
                                ];
                            } else {
                                if (!empty($_service['options']['option'])) {
                                    foreach ($_service['options']['option'] as $_option) {
                                        if (is_array($_option)) {
                                            if ($_option['code'] == 'INT_EXTRA_COVER') {
                                                if (!$this->getConfigData('auspost_add_extra_cover_price_int_service')) {
                                                    continue;
                                                }
                                            }
                                            if ($_option['code'] == 'INT_EXTRA_COVER') {
                                                if (!$this->getConfigData('auspost_add_extra_cover_price_int_service')) {
                                                    continue;
                                                }
                                            }

                                            if ($_option['code'] == 'INT_SIGNATURE_ON_DELIVERY') {
                                                if ($this->getConfigData('auspost_disable_signature_services')) {
                                                    continue;
                                                }
                                            }

                                            $options[$_option['code']] = [
                                                'code' => $_option['code'],
                                                'name' => $_option['name'],
                                                'max_extra_cover' => $_service['max_extra_cover'],
                                            ];
                                        } else {

                                            //Skip to define service if code was not available. 
                                            if (empty($_option)) continue;

                                            if ($_service['options']['option']['code'] == 'INT_EXTRA_COVER') {
                                                if (!$this->getConfigData('auspost_add_extra_cover_price_int_service')) {
                                                    continue;
                                                }
                                            }

                                            if ($_service['options']['option']['code'] == 'INT_SIGNATURE_ON_DELIVERY') {
                                                if ($this->getConfigData('auspost_disable_signature_services')) {
                                                    continue;
                                                }
                                            }

                                            $options[$_service['options']['option']['code']] = [
                                                'code' => $_service['options']['option']['code'],
                                                'name' => $_service['options']['option']['name'],
                                                'max_extra_cover' => isset($_service['max_extra_cover']) ? $_service['max_extra_cover'] : null,
                                            ];
                                        }
                                    }
                                }
                            }
                            $_services[$_service['code']]['options'] = $options;
                        }
                    }
                }
            }
        }
        return $_services;
    }

    public function getAllowedMethods()
    {
        return ['auspost' => $this->getConfigData('auspost_method_name')];
    }

    protected function apiRequest($action, $params = [], $auth = true)
    {
        $url = $this->_apiHttps . '/' . $action . '.xml?' . $this->_helperData->buildHttpQuery($params);
        $headers = [
            "Accept: text/html,application/xhtml+xml,application/xml",
            "Cookie: OBBasicAuth=fromDialog",
        ];
        $res = $this->_helperData->ausPostValidation($url, $headers, true);
        return $this->_helperData->parseXml($res);
    }

    public function getFinalPriceWithHandlingFee($cost)
    {
        $handlingFee = $this->getConfigData('handling_fee');
        $handlingType = $this->getConfigData('handling_type');
        if (!$handlingType) {
            $handlingType = self::HANDLING_TYPE_FIXED;
        }
        $handlingAction = $this->getConfigData('handling_action');
        $this->numBoxes = $this->_itemPackage;
        if (!$handlingAction || $handlingAction == "O") {
            $handlingAction = self::HANDLING_ACTION_PERORDER;
            $this->numBoxes = 1;
        }

        return $handlingAction == self::HANDLING_ACTION_PERPACKAGE ? $this->_getPerpackagePrice($cost, $handlingType, $handlingFee) : $this->_getPerorderPrice($cost, $handlingType, $handlingFee);
    }

    protected function _getPerpackagePrice($cost, $handlingType, $handlingFee)
    {

        if ($handlingType == self::HANDLING_TYPE_PERCENT) {
            return $cost + (($cost * $handlingFee / 100) * $this->numBoxes);
        }

        return $cost + ($handlingFee * $this->numBoxes);
    }

    protected function _getPerorderPrice($cost, $handlingType, $handlingFee)
    {
        if ($handlingType == self::HANDLING_TYPE_PERCENT) {
            return $cost + ($cost * $this->numBoxes * $handlingFee / 100);
        }

        return $cost + ($this->numBoxes * $handlingFee);
    }
}
