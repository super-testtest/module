<?php
namespace Biztech\Auspost\Model\Carrier;
class Pack
{
    private $boxes = null;
    private $packedBoxes = null;
    private $level = -1;
    private $containerDimensions = null;

    /**
     * Pack constructor.
     *
     * @param null $boxes
     * @param null $container
     */
    function __construct($boxes = null, $container = null)
    {
        if (isset($boxes) && is_array($boxes)) {
            $this->boxes = $boxes;
            $this->packedBoxes = [];

            if (!is_array($container)) {
                $this->containerDimensions = $this->calcContainerDimensions();
            } else {
                if (!is_array($container)) {
                    $this->containerDimensions = $this->calcContainerDimensions();
                } else {
                    if (!array_key_exists('length', $container) 
                        || !array_key_exists('width', $container)
                    ) {
                        throw new \InvalidArgumentException("Function _pack only accepts array (length, width, height) as argument for $container");
                    }

                    $this->containerDimensions['length'] = $container['length'];
                    $this->containerDimensions['width'] = $container['width'];
                }
            }
        }
    }

    /**
     * @param null $boxes
     * @param null $container
     */
    public function pack($boxes = null, $container = null)
    {
        if (isset($boxes) && is_array($boxes)) {
            $this->boxes = $boxes;
            $this->packedBoxes = [];
            $this->level = -1;
            $this->containerDimensions = null;

            if (!is_array($container)) {
                $this->containerDimensions = $this->calcContainerDimensions();
            } else {
                if (!array_key_exists('length', $container) 
                    || !array_key_exists('width', $container)
                ) {
                    throw new \InvalidArgumentException("Pack function only accepts array (length, width, height) as argument for \$container");
                }

                $this->containerDimensions['length'] = $container['length'];
                $this->containerDimensions['width'] = $container['width'];
            }
        }

        if (!isset($this->boxes)) {
            throw new \InvalidArgumentException("Pack function only accepts array (length, width, height) as argument for \$boxes or no boxes given!");
        }

        $this->packLevel();
    }

    /**
     * @return array|null
     */
    public function getRemainingBoxes()
    {
        return $this->boxes;
    }

    /**
     * @return array|null
     */
    public function getPackedBoxes()
    {
        return $this->packedBoxes;
    }

    /**
     * @return array|null
     */
    public function getContainerDimensions()
    {
        return $this->containerDimensions;
    }

    /**
     * @return int
     */
    public function getContainerVolume()
    {
        if (!isset($this->containerDimensions)) {
            return 0;
        }

        return $this->getVolume($this->containerDimensions);
    }

    /**
     * @return int
     */
    public function getLevels()
    {
        return $this->level + 1;
    }

    /**
     * @return int
     */
    public function getPackedVolume()
    {
        if (!isset($this->packedBoxes)) {
            return 0;
        }

        $volume = 0;

        for ($i = 0; $i < count(array_keys($this->packedBoxes)); $i++) {
            foreach ($this->packedBoxes[$i] as $box) {
                $volume += $this->getVolume($box);
            }
        }

        return $volume;
    }

    /**
     * @return int
     */
    public function getRemainingVolume()
    {
        if (!isset($this->packedBoxes)) {
            return 0;
        }

        $volume = 0;

        foreach ($this->boxes as $box) {
            $volume += $this->getVolume($box);
        }

        return $volume;
    }

    /**
     * @param  int $level
     * @return array
     */
    public function getLevelDimensions($level = 0)
    {
        if ($level < 0 || $level > $this->level || !array_key_exists($level, $this->packedBoxes)) {
            throw new \OutOfRangeException("Level {$level} not found!");
        }

        $boxes = $this->packedBoxes;
        $edges = ['length', 'width', 'height'];

        $longEdge = $this->calcLongestEdge($boxes[$level], $edges);
        $edges = array_diff($edges, [$longEdge['edge_name']]);

        $sle = $this->calcLongestEdge($boxes[$level], $edges);

        return array(
            'width' => $longEdge['edge_size'],
            'length' => $sle['edge_size'],
            'height' => $boxes[$level][0]['height']
        );
    }

    /**
     * @param  $boxes
     * @param  array $edges
     * @return array
     */
    public function calcLongestEdge($boxes, $edges = ['length', 'width', 'height'])
    {
        if (!isset($boxes) || !is_array($boxes)) {
            throw new \InvalidArgumentException('calcLongestEdge function requires an array of boxes, ' . \gettype($boxes) . ' given');
        }

        $longEdge = null;        // Longest edge
        $lef = null;    // Edge field (length | width | height) that is longest
        $key = null;
        foreach ($boxes as $key => $box) {
            foreach ($edges as $edge) {
                if (array_key_exists($edge, $box) && $box[$edge] > $longEdge) {
                    $longEdge = $box[$edge];
                    $lef = $edge;
                }
            }
        }

        return [
            'edge_size' => $longEdge,
            'edge_name' => $lef
        ];
    }

    /**
     * @return array
     */
    public function calcContainerDimensions()
    {
        if (!isset($this->boxes)) {
            return [
                'length' => 0,
                'width' => 0,
                'height' => 0
            ];
        }

        $boxes = $this->boxes;

        $edges = ['length', 'width', 'height'];

        $longEdge = $this->calcLongestEdge($boxes, $edges);
        $edges = array_diff($edges, [$longEdge['edge_name']]);

        $sle = $this->calcLongestEdge($boxes, $edges);

        return [
            'length' => $longEdge['edge_size'],
            'width' => $sle['edge_size'],
            'height' => 0
        ];
    }

    /**
     * @param  $array
     * @param  $el1
     * @param  $el2
     * @return mixed
     */
    public function swap($array, $el1, $el2)
    {
        if (!array_key_exists($el1, $array) || !array_key_exists($el2, $array)) {
            throw new \InvalidArgumentException("Both element to be swapped need to exist in the supplied array");
        }

        $tmp = $array[$el1];
        $array[$el1] = $array[$el2];
        $array[$el2] = $tmp;

        return $array;
    }

    /**
     * @param  $box
     * @return mixed
     */
    public function getVolume($box)
    {
        if (!is_array($box) || count(array_keys($box)) < 3) {
            throw new \InvalidArgumentException("getVolume function only accepts arrays with 3 values (length, width, height)");
        }

        $box = array_values($box);

        return $box[0] * $box[1] * $box[2];
    }

    /**
     * @param  $box
     * @param  $space
     * @return bool
     */
    private function tryFitBox($box, $space)
    {
        if (count($box) < 3) {
            throw new \InvalidArgumentException("tryFitBox function parameter $box only accepts arrays with 3 values (length, width, height)");
        }

        if (count($space) < 3) {
            throw new \InvalidArgumentException("tryFitBox function parameter $space only accepts arrays with 3 values (length, width, height)");
        }

        for ($i = 0; $i < count($box); $i++) {
            if (array_key_exists($i, $space)) {
                if ($box[$i] > $space[$i]) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * @param  $box
     * @param  $space
     * @return bool
     */
    public function boxFits($box, $space)
    {
        $box = array_values($box);
        $space = array_values($space);

        if ($this->tryFitBox($box, $space)) {
            return true;
        }

        for ($i = 0; $i < count($box); $i++) {
            $tBox = $box;

            unset($tBox[$i]);
            $tKeys = array_keys($tBox);
            $sBox = $this->swap($box, $tKeys[0], $tKeys[1]);

            if ($this->tryFitBox($sBox, $space)) {
                return true;
            }
        }

        return false;
    }

    /**
     *
     */
    private function packLevel()
    {
        $biggestBoxIndex = null;
        $biggestSurface = 0;

        $this->level++;

        foreach ($this->boxes as $k => $box) {
            $surface = $box['length'] * $box['width'];

            if ($surface > $biggestSurface) {
                $biggestSurface = $surface;
                $biggestBoxIndex = $k;
            } else if ($surface == $biggestSurface) {
                if (!isset($biggestBoxIndex) || (isset($biggestBoxIndex) && $box['height'] < $this->boxes[$biggestBoxIndex]['height'])) {
                    $biggestBoxIndex = $k;
                }
            }
        }

        $biggestBox = $this->boxes[$biggestBoxIndex];
        $this->packedBoxes[$this->level][] = $biggestBox;

        $this->containerDimensions['height'] += $biggestBox['height'];

        unset($this->boxes[$biggestBoxIndex]);

        if (count($this->boxes) == 0) {
            return;
        }

        $cArea = $this->containerDimensions['length'] * $this->containerDimensions['width'];
        $pArea = $biggestBox['length'] * $biggestBox['width'];

        if ($cArea - $pArea <= 0) {
            $this->packLevel();
        } else { // Space left, check if a package fits in
            $spaces = [];

            if (!empty($this->containerDimensions['length'])) {
                if ($this->containerDimensions['length'] - $biggestBox['length'] > 0) {
                    $spaces[] = [
                        'length' => $this->containerDimensions['length'] - $biggestBox['length'],
                        'width' => $this->containerDimensions['width'],
                        'height' => $biggestBox['height']
                    ];
                }
            }

            if (!empty($biggestBox)) {
                if ($this->containerDimensions['width'] - $biggestBox['width'] > 0) {
                    $spaces[] = [
                        'length' => $biggestBox['length'],
                        'width' => $this->containerDimensions['width'] - $biggestBox['width'],
                        'height' => $biggestBox['height']
                    ];
                }
            }

            foreach ($spaces as $space) {
                $this->fillSpace($space);
            }

            if (count($this->boxes) > 0) {
                $this->packLevel();
            }
        }
    }

    /**
     * @param $space
     */
    private function fillSpace($space)
    {
        $sVolume = $this->getVolume($space);

        $fittingBoxIndex = null;
        $fittingBoxVolume = null;

        foreach ($this->boxes as $k => $box) {
            if ($this->getVolume($box) > $sVolume) {
                continue;
            }

            if ($this->boxFits($box, $space)) {
                $bVolume = $this->getVolume($box);

                if (!isset($fittingBoxVolume) || $bVolume > $fittingBoxVolume) {
                    $fittingBoxIndex = $k;
                    $fittingBoxVolume = $bVolume;
                }
            }
        }

        if (isset($fittingBoxIndex)) {
            $box = $this->boxes[$fittingBoxIndex];

            $this->packedBoxes[$this->level][] = $this->boxes[$fittingBoxIndex];
            unset($this->boxes[$fittingBoxIndex]);

            $newSpaces = [];

            if ($space['length'] - $box['length'] > 0) {
                $newSpaces[] = [
                    'length' => $space['length'] - $box['length'],
                    'width' => $space['width'],
                    'height' => $box['height']
                ];
            }
            if ($space['width'] - $box['width'] > 0) {
                $newSpaces[] = [
                    'length' => $box['length'],
                    'width' => $space['width'] - $box['width'],
                    'height' => $box['height']
                ];
            }

            if (count($newSpaces) > 0) {
                foreach ($newSpaces as $newSpace) {
                    $this->fillSpace($newSpace);
                }
            }
        }
    }

    /**
     * @param  array|null $packedBoxes
     * @return Pack
     */
    public function setPackedBoxes($packedBoxes)
    {
        $this->packedBoxes = $packedBoxes;
        return $this;
    }
}
