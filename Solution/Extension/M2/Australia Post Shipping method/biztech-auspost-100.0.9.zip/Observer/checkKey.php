<?php

namespace Biztech\Auspost\Observer;

use Magento\Framework\Event\ObserverInterface;

class checkKey implements ObserverInterface
{

    const XML_PATH_ACTIVATIONKEY = 'auspost/activation/key';
    const XML_PATH_DATA = 'auspost/activation/data';

    protected $scopeConfig;
    protected $encryptor;
    protected $configFactory;
    protected $helper;
    protected $objectManager;
    protected $request;
    protected $resourceConfig;
    protected $configValueFactory;
    protected $zend;
    protected $cacheTypeList;
    protected $cacheFrontendPool;

    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        \Magento\Config\Model\Config\Factory $configFactory,
        \Biztech\Auspost\Helper\Data $helper,
        \Magento\Framework\ObjectManagerInterface $objectmanager,
        \Magento\Framework\App\RequestInterface $request,
        \Zend\Json\Json $zend,
        \Magento\Config\Model\ResourceModel\Config $resourceConfig,
        \Magento\Framework\App\Config\ValueFactory $configValueFactory,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\Framework\App\Cache\Frontend\Pool $cacheFrontendPool
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->_encryptor = $encryptor;
        $this->_configFactory = $configFactory;
        $this->_helper = $helper;
        $this->_objectManager = $objectmanager;
        $this->_request = $request;
        $this->_zend = $zend;
        $this->_resourceConfig = $resourceConfig;
        $this->_configValueFactory = $configValueFactory;
        $this->_cacheTypeList = $cacheTypeList;
        $this->_cacheFrontendPool = $cacheFrontendPool;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $params = $this->_request->getParam('groups');
        
        $k = $params['activation']['fields']['key']['value'];
        $s = '';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, sprintf('https://www.appjetty.com/extension/licence.php'));
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'key=' . urlencode($k) . '&domains=' . urlencode(implode(',', $this->_helper->getAllStoreDomains())) . '&sec=magento2-australianpost');
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $content = curl_exec($ch);
        $res1 = $this->_zend->decode($content);
        $res = (array)$res1;
        $moduleStatus = $this->_resourceConfig;
        if (empty($res)) {
            $moduleStatus->saveConfig('auspost/activation/key', "");
            $moduleStatus->saveConfig('auspost/enableextension/enabled', 0);
            $data = $this->scopeConfig('auspost/activation/data');
            $this->_resourceConfig->saveConfig('auspost/activation/data', $data, 'default', 0);
            $this->_resourceConfig->saveConfig('auspost/activation/websites', '', 'default', 0);
            $this->_resourceConfig->saveConfig('auspost/activation/store', '', 'default', 0);
            return;
        }
        $data = '';
        $web = '';
        $en = '';
        if (isset($res['dom']) && intval($res['c']) > 0 && intval($res['suc']) == 1) {
            $data = $this->_encryptor->encrypt(base64_encode($this->_zend->encode($res1)));
            if (!$s) {
                if (isset($params['activation']['fields']['store']['value'])) {
                    $s = $params['activation']['fields']['store']['value'];
                }
            }
            $en = $res['suc'];
            if (isset($s) && $s != null) {
                $web = $this->_encryptor->encrypt($data . implode(',', $s) . $data);
            } else {
                $web = $this->_encryptor->encrypt($data . $data);
            }
        } else {
            $moduleStatus->saveConfig('auspost/activation/key', "", 'default', 0);
            $moduleStatus->saveConfig('auspost/enableextension/enabled', 0, 'default', 0);
            $this->_resourceConfig->saveConfig('auspost/activation/store', '', 'default', 0);
        }

        $this->_resourceConfig->saveConfig('auspost/activation/data', $data, 'default', 0);
        $this->_resourceConfig->saveConfig('auspost/activation/websites', $web, 'default', 0);
        $this->_resourceConfig->saveConfig('auspost/activation/en', $en, 'default', 0);
        $this->_resourceConfig->saveConfig('auspost/activation/installed', 1, 'default', 0);

        //refresh config cache after save
        $types = ['config', 'full_page'];
        foreach ($types as $type) {
            $this->_cacheTypeList->cleanType($type);
        }
        foreach ($this->_cacheFrontendPool as $cacheFrontend) {
            $cacheFrontend->getBackend()->clean();
        }
    }
}
