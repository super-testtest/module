<?php
/*logger namespace.*/
namespace Biztech\Auspost\Logger;

/**
 * Class for logger
 */
class Logger extends \Monolog\Logger
{
}
