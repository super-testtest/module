define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/shipping-rates-validator',
        'Magento_Checkout/js/model/shipping-rates-validation-rules',
        '../model/shipping-rates-validator',
        '../model/shipping-rates-validation-rules'
    ],
    function (
        Component,
        defaultShippingRatesValidator,
        defaultShippingRatesValidationRules,
        auspostshippingRatesValidator,
        auspostshippingRatesValidationRules
    ) {
        'use strict';
        defaultShippingRatesValidator.registerValidator('auspost', auspostshippingRatesValidator);
        defaultShippingRatesValidationRules.registerRules('auspost', auspostshippingRatesValidationRules);
        return Component;
    }
);