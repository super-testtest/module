<?php

namespace Biztech\Auspost\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Directory\Helper\Data;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\App\ResourceConnection;
/**
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{

    /**
     * EAV setup factory
     *
     * @var EavSetupFactory
     */
    private $_eavSetupFactory;
    protected $_resource;
    private $_directoryData;

    /**
     * Init
     *
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(
        EavSetupFactory $eavSetupFactory,
        Data $directoryData,
        ResourceConnection $resource
    ) {
        $this->_eavSetupFactory = $eavSetupFactory;
        $this->_resource = $resource;
        $this->_directoryData = $directoryData;
    }

    /**
     * {@inheritdoc}
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {

        $installer = $setup;
        $installer->startSetup();

        /**
 * @var EavSetup $eavSetup 
*/
        $eavSetup = $this->_eavSetupFactory->create(['setup' => $setup]);
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY, 'auspost_package_type', [
                'type' => 'int',
                'backend' => '',
                'frontend' => '',
                'label' => 'Australia Post Package Type',
                'input' => 'select',
                'class' => '',
                'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => 0,
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => true,
                'unique' => false,
                'source' => 'Biztech\Auspost\Model\Entity\Attribute\Source\Packagetype',
                'apply_to' => 'simple,configurable,virtual,bundle,downloadable'
            ]
        );

        //install states for australia
        $data = [
            ['AU', 'ACT', 'Australia Capital Territory'],
            ['AU', 'NSW', 'New South Wales'],
            ['AU', 'NT', 'Northern Territory'],
            ['AU', 'QLD', 'Queensland'],
            ['AU', 'SA', 'South Australia'],
            ['AU', 'TAS', 'Tasmania'],
            ['AU', 'VIC', 'Victoria'],
            ['AU', 'WA', 'Western Australia'],
        ];
        foreach ($data as $row) {
            $dbConnection = $setup->getConnection();
            $select = $dbConnection->select()
                ->from($setup->getTable('directory_country_region'))
                ->where('country_id ="' . $row[0] . '" AND code =  "' . $row[1] . '"');
            $result = $dbConnection->fetchOne($select);
            if (!$result) {
                $bind = ['country_id' => $row[0], 'code' => $row[1], 'default_name' => $row[2]];
                $setup->getConnection()->insert($setup->getTable('directory_country_region'), $bind);
                $regionId = $setup->getConnection()->lastInsertId($setup->getTable('directory_country_region'));

                $bind = ['locale' => 'en_US', 'region_id' => $regionId, 'name' => $row[2]];
                $setup->getConnection()->insert($setup->getTable('directory_country_region_name'), $bind);
            }
        }

        //alter table ALTER TABLE quote_address MODIFY shipping_method VARCHAR(255);
        $setup->getConnection()->changeColumn(
            $setup->getTable('quote_address'), 'shipping_method', 'shipping_method', [
            'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            'length' => 255,
            'comment' => 'Shipping Method'
            ]
        );
    }

    /**
     * @return ResourceConnection
     */
    public function getResource()
    {
        return $this->_resource;
    }

}
