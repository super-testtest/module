<?php
namespace Biztech\Auspost\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.1') < 0) {
            //View File Fix For Frontend JS Layout
            //Auspost php Update to Separate Extra Cover Shipping
        }
        if (version_compare($context->getVersion(), '1.0.2') < 0) {
            //Fixed Compilation Issues
        }

        if (version_compare($context->getVersion(), '1.0.3') < 0) {
            //Fixed Compilation Issues
        }

        $setup->endSetup();
    }
}